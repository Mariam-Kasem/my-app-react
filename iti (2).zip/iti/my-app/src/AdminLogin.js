import React, { useState } from "react";
import "./style.css";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState(null);

  function handleSubmit(e) {
    e.preventDefault();

    if (!username.trim() || !password) {
      setMessage({ type: "error", text: "Please enter username and password." });
      return;
    }

    setMessage({ type: "info", text: "Checking credentials..." });

    setTimeout(() => {
      if (password === "admin123") {
        setMessage({ type: "success", text: "Login successful!" });
      } else {
        setMessage({ type: "error", text: "Invalid username or password" });
      }

      setUsername("");
      setPassword("");
    }, 800);
  }

  return (
    <div className="container">
      <div className="login-box">
        <div className="icon">
          <svg
            width="48"
            height="48"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle cx="12" cy="8" r="3" stroke="#ffffff" strokeWidth="1.2" />
            <path
              d="M4 20c0-4 4-6 8-6s8 2 8 6"
              stroke="#ffffff"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        
        <h1 className="title">Admin Login</h1>

        <form onSubmit={handleSubmit}>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="username"
            className="input"
          />

          <div style={{ position: "relative" }}>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
              type={showPassword ? "text" : "password"}
              className="input"
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="toggle-btn"
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>

          <button type="submit" className="login-btn">
            Login
          </button>

          {message && (
            <div
              className={`alert ${
                message.type === "error"
                  ? "alert-error"
                  : message.type === "success"
                  ? "alert-success"
                  : "alert-info"
              }`}
            >
              {message.text}
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
