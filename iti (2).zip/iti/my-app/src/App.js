import React, { version } from "react";
import AdminLogin from "./AdminLogin";

function App() {
  return (
    <div className="App">
      <AdminLogin />
    </div>
  );
}

export default App;
